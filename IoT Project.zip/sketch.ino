#include <WiFi.h>
#include "DHTesp.h"
#include "ThingSpeak.h"
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

const int DHT_PIN = 15;
DHTesp dhtSensor;

// Virtual Wi-Fi network provided by Wokwi
const char* WIFI_NAME = "Wokwi-GUEST";
const char* WIFI_PASSWORD = "";

// ThingSpeak Channel Credentials
unsigned long myChannelNumber = 3489681; 
const char* myWriteApiKey = "EZ4U4L7R84GC7EF2";

WiFiClient client;

void setup() {
  Serial.begin(115200);
  
  // Initialize SSD1306 OLED Display
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("SSD1306 allocation failed"));
    for (;;); // Don't proceed, loop forever
  }
  
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 10);
  display.println("Initializing System...");
  display.display();

  // Initialize DHT22 Sensor on GPIO 15
  dhtSensor.setup(DHT_PIN, DHTesp::DHT22);

  // Connect to Wokwi virtual Wi-Fi
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_NAME, WIFI_PASSWORD);
  Serial.print("Connecting to Wi-Fi");
  
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nConnected to Wi-Fi!");

  // Initialize ThingSpeak library
  ThingSpeak.begin(client);
}

void loop() {
  // 1. Read sensor values from DHT22 first
  TempAndHumidity data = dhtSensor.getTempAndHumidity();

  // Check if sensor reading failed
  if (isnan(data.temperature) || isnan(data.humidity)) {
    Serial.println("Failed to read from DHT22 sensor!");
    
    display.clearDisplay();
    display.setCursor(0, 0);
    display.println("SENSOR ERROR!");
    display.display();
    
    delay(2000);
    return;
  }

  float temp = data.temperature;
  float humi = data.humidity;

  // 2. Render real-time data onto OLED screen
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);

  display.setCursor(0, 0);
  display.println("IoT NODE: ACTIVE");
  display.println("---------------------");
  display.printf("Temp: %.1f C\n", temp);
  display.printf("Humi: %.1f %%\n", humi);

  if (temp > 30.0) {
    display.println("\n[ALERT: HIGH TEMP!]");
  } else {
    display.println("\nStatus: Normal");
  }

  display.display();

  // 3. Print temperature and humidity to Serial Monitor
  Serial.println("Temp: " + String(temp, 2) + " °C | Humidity: " + String(humi, 1) + " %");

  // 4. Assign values and send payload to ThingSpeak
  ThingSpeak.setField(1, temp); // Field 1: Temperature
  ThingSpeak.setField(2, humi); // Field 2: Humidity

  int httpCode = ThingSpeak.writeFields(myChannelNumber, myWriteApiKey);
  
  if (httpCode == 200) {
    Serial.println("ThingSpeak update successful.");
  } else {
    Serial.println("Error updating ThingSpeak. HTTP Code: " + String(httpCode));
  }

  // ThingSpeak requires a minimum 15-second delay between updates
  delay(15000);
}